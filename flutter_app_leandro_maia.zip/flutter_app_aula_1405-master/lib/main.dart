import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return (MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.greenAccent,
        appBar: AppBar(
          title: Text("Minha Row"),
        ),
        body: HelloRectangle(),
      ),
    ));
  }
}

class HelloRectangle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: Adicionar uma nova Row;
    return (Container(
      child: Center(
        child: ListView(
          children: <Widget>[
            Row(

              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.cake,
                    size: 60,
                    color: Colors.black,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Bolo de chocolate.',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                )
              ],
            ),
            Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.cake,
                    size: 60,
                    color: Colors.orange,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Bolo de cenoura',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                )
              ],
            ),

            Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.cake,
                    size: 60,
                    color: Colors.yellow,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Bolo de abacaxi',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                )
              ],
            ),
            Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.cake,
                    size: 60,
                    color: Colors.green,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Bolo de limão',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                )
              ],
            ),

            Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.cake,
                    size: 60,
                    color: Colors.red,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Bolo de morango',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                )
              ],
            ),

            Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.call,
                    size: 60,
                    color: Colors.orange,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Telefone Fixo',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                )
              ],
            ),

            Row(
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Icon(
                    Icons.call,
                    size: 60,
                    color: Colors.orange,
                  ),
                ),
                Expanded(
                  child: Text(
                    'Celular',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    ));
  }
}
